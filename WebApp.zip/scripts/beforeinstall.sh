#!/bin/bash
rm /var/www/html/index.php
